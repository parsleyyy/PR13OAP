﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ПР_13
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Практическая работа №13");
            Console.WriteLine("Выполнил студент 2 курса группы ИСП.20А");
            Console.WriteLine("Рылеев Александр");
            Console.WriteLine("Вариант №6");
            Console.WriteLine();

            string path = @"Input.txt";
          
            double M = 0.029;
            double R = 8.31;
            double P = 8e4;
            double T = 340;
            double V = 1.58E-3;


            StreamWriter sw = new StreamWriter(path, false);

            sw.WriteLine(M);
            sw.WriteLine(R);
            sw.WriteLine(P);
            sw.WriteLine(T);
            sw.WriteLine(V);

            sw.Close();


            //чтение из файла Input.txt

            StreamReader sr = new StreamReader(path);

            Console.WriteLine("Значения величин:");
            double M_read = Convert.ToDouble(sr.ReadLine());
            Console.WriteLine($"Молярная масса M = {M_read} кг/моль");
            double R_read = Convert.ToDouble(sr.ReadLine());
            Console.WriteLine($"Газовая постоянная R = {R_read}дж/моль*K");
            double P_read = Convert.ToDouble(sr.ReadLine());
            Console.WriteLine($"Давление P = {P_read}Па");
            double T_read = Convert.ToDouble(sr.ReadLine());
            Console.WriteLine($"Температура T = {T_read}K");
            double V_read = Convert.ToDouble(sr.ReadLine());
            Console.WriteLine($"Объём V = {V_read}м^3");
            Console.WriteLine();

            Console.WriteLine("Запись значений из файла Input.txt произведена!");
            Console.WriteLine();

            //вычисление результата по формуле

            double solve = Math.Round((P_read * V_read * M_read)/(R_read * T_read),8);//формула



            //запись результата в файл Result.txt

            string path1 = @"Result.txt";

            StreamWriter sw1 = new StreamWriter(path1, false);

            sw1.WriteLine(solve);

            sw1.Close();

            Console.WriteLine("Подсчет и запись выполнены и занесены в файл Result.txt!");

            Console.ReadKey();
        }
    }
}
